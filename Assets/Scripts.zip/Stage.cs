﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
public class Stage : MonoBehaviour {

    [SerializeField] int star;
    public int Star
    {
        set { star = value; }
        get { return star; }
    }
    HashSet<int> hitTargets = new HashSet<int>();
    public Target[] targets;
    int HitTargetCount
    {
        get { return hitTargets.Count; }
    }
    public int condition01 = 1;
    public int condition02 = 2;
    new GameObject gameObject;
    public void SetActive(bool value)
    {
        gameObject.SetActive(value);
    }
    public void Init(int star)
    {
        this.star = star;
        gameObject = base.gameObject;
        //targets = GetComponentsInChildren<Target>();
        
        for (int i = 0; i < targets.Length; i++)
        {
            targets[i].Init(this,i);
        }
        
        SetActive(false);
    }
    //사용하는 레이저 종류 레이저 갯수 시작 위치를 알 수 있어야 함
    public LaserSet[] laserSets;
    [Serializable]
    public struct LaserSet
    {
        public int laserNum;
        public Vector2 position;
    }
    public void Clear()
    {
        hitTargets.Clear();        
    }
    public void HitTarget(int targetNumber)
    {
        if (!hitTargets.Contains(targetNumber))
        {
            hitTargets.Add(targetNumber);
            if (HitTargetCount == targets.Length)
            {
                GameManager.Instance.StageClear();
            }
        }
    }
}
