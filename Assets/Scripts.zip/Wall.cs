﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public enum WallType { RBOX,NRBOX}
public enum WallTag {REFLECTION,NONREFLECTION }

public class Wall : MonoBehaviour {

    [SerializeField] SpriteRenderer sp;
    [SerializeField] WallData wallData;
    [SerializeField] WallType wallType;
    [SerializeField] float width = 1f;
    [SerializeField] float height = 1f;
    [SerializeField] float rotation = 0f;
    [SerializeField] Transform tr;
    public WallType WallType
    {
        get
        {
            return wallType;
        }

        set
        {
            wallType = value;
            switch (wallType)
            {
                case WallType.RBOX:
                    tag = WallTag.REFLECTION.ToString();
                    
                    break;
                case WallType.NRBOX:
                    tag = WallTag.NONREFLECTION.ToString();
                    break;
            }
        }
    }

    public float Width
    {
        get
        {
            return width;
        }

        set
        {
            width = value;
            sp.size = Vector2.right*width * wallData.unit+ Vector2.up * sp.size.y;
        }
    }

    public float Height
    {
        get
        {
            return height;
        }

        set
        {
            height = value;
            sp.size = Vector2.right * sp.size.x + Vector2.up * height * wallData.unit;
        }
    }
    void OnValidate()
    {
        Width = width;
        Height = height;
        tr.eulerAngles = Vector3.forward * rotation;
        WallType = wallType;
    }
}
