﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Target : MonoBehaviour {
    public Stage stage;
    int targetNumber;
    public void Init(Stage stage,int targetNumber)
    {

        this.stage = stage;
        this.targetNumber = targetNumber;
    }
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("LASERGUIDE"))
        {
            stage.HitTarget(targetNumber);
        }
    }
}
