﻿using UnityEngine;
using UnityEditor;

public class MyColor
{
    public readonly static Color DEFAULT = new Color(251f/255,255f/255,167f/255, 1);
    
    public readonly static Color UNENABLED = new Color(177f/255, 179f/255, 155f/255, 1);
}