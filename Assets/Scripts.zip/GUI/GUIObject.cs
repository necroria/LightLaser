﻿using UnityEngine;
using System.Collections;

public class GUIObject : MonoBehaviour
{

    public void SetActive(bool value)
    {
        gameObject.SetActive(value);
    }
}
