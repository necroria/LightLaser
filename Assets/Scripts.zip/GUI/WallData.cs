﻿using UnityEngine;
using UnityEditor;
using System;
[Serializable]
public class WallPreSet
{
    public WallType type;
    public WallTag tag;
    public Sprite sprite;
}
[CreateAssetMenu(fileName = "WallData", menuName = "Wall data")]
public class WallData : ScriptableObject
{    
    public WallPreSet[] wallPreset;
    public float unit = 0.32f;
}